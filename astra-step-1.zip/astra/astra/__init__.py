import os

from flask import Flask

from . import db


def create_app(test_config=None):
    """Application factory. Tests pass in their own config (e.g. a temp database)."""
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        SECRET_KEY="dev-change-me",
        DATABASE=os.path.join(app.instance_path, "astra.sqlite3"),
    )
    if test_config:
        app.config.update(test_config)

    os.makedirs(app.instance_path, exist_ok=True)
    db.init_app(app)

    from . import routes

    app.register_blueprint(routes.bp)
    app.add_template_filter(routes.ordinal, "ordinal")
    return app
