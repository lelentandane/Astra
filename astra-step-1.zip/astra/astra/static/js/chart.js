/* Chart page: draws the wheel and links it to the placements table. */
(function () {
  "use strict";

  var dataEl = document.getElementById("chart-data");
  var mount = document.getElementById("wheel");
  if (!dataEl || !mount) return;

  var svg = window.Astra.mountWheel(mount, JSON.parse(dataEl.textContent));
  var rows = document.querySelectorAll("[data-row]");

  function setActive(body, on) {
    var planet = svg.querySelector('.planet[data-body="' + body + '"]');
    var row = document.querySelector('[data-row="' + body + '"]');
    if (planet) planet.classList.toggle("is-active", on);
    if (row) row.classList.toggle("is-active", on);
  }

  svg.querySelectorAll(".planet").forEach(function (el) {
    var body = el.getAttribute("data-body");
    el.addEventListener("mouseenter", function () { setActive(body, true); });
    el.addEventListener("mouseleave", function () { setActive(body, false); });
    el.addEventListener("focus", function () { setActive(body, true); });
    el.addEventListener("blur", function () { setActive(body, false); });
  });

  rows.forEach(function (row) {
    var body = row.getAttribute("data-row");
    row.addEventListener("mouseenter", function () { setActive(body, true); });
    row.addEventListener("mouseleave", function () { setActive(body, false); });
  });
})();
