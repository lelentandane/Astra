/*
 * Astra chart wheel.
 * Builds an SVG string from chart data, so the same code runs in the browser
 * and in Node (handy for testing the geometry).
 *
 * Geometry: whole-sign houses. The Ascendant's sign starts at the left edge
 * (9 o'clock) and the zodiac runs counter-clockwise from there.
 */
(function (root) {
  "use strict";

  var TEXT = "\uFE0E";
  var SIGNS = [
    { name: "Aries", glyph: "\u2648" + TEXT, element: "fire" },
    { name: "Taurus", glyph: "\u2649" + TEXT, element: "earth" },
    { name: "Gemini", glyph: "\u264A" + TEXT, element: "air" },
    { name: "Cancer", glyph: "\u264B" + TEXT, element: "water" },
    { name: "Leo", glyph: "\u264C" + TEXT, element: "fire" },
    { name: "Virgo", glyph: "\u264D" + TEXT, element: "earth" },
    { name: "Libra", glyph: "\u264E" + TEXT, element: "air" },
    { name: "Scorpio", glyph: "\u264F" + TEXT, element: "water" },
    { name: "Sagittarius", glyph: "\u2650" + TEXT, element: "fire" },
    { name: "Capricorn", glyph: "\u2651" + TEXT, element: "earth" },
    { name: "Aquarius", glyph: "\u2652" + TEXT, element: "air" },
    { name: "Pisces", glyph: "\u2653" + TEXT, element: "water" }
  ];

  var COLORS = {
    fire: "#F3D5CB",
    earth: "#DAE6D0",
    air: "#DCE4F3",
    water: "#D3E8E4",
    ink: "#24163A",
    soft: "#5A4E72",
    line: "#B7ADCB",
    accent: "#9A3B5C",
    paper: "#F8F6FC"
  };

  var SIZE = 640;
  var C = SIZE / 2;
  var R = { outer: 306, sign: 262, houseOuter: 172, inner: 150, glyph: 224, degree: 199 };

  var FONT_SYMBOLS =
    "'Noto Sans Symbols','Noto Sans Symbols 2','Segoe UI Symbol','Apple Symbols','DejaVu Sans',sans-serif";

  function fmt(n) {
    return n.toFixed(2);
  }

  // Angle on screen (degrees, counter-clockwise from 3 o'clock) for a longitude.
  function screenAngle(longitude, ascSignIndex) {
    var rel = (((longitude - ascSignIndex * 30) % 360) + 360) % 360;
    return 180 + rel;
  }

  function point(radius, angleDeg) {
    var a = (angleDeg * Math.PI) / 180;
    return [C + radius * Math.cos(a), C - radius * Math.sin(a)];
  }

  function wedge(rInner, rOuter, a1, a2) {
    var p1 = point(rOuter, a1);
    var p2 = point(rOuter, a2);
    var p3 = point(rInner, a2);
    var p4 = point(rInner, a1);
    return (
      "M" + fmt(p1[0]) + " " + fmt(p1[1]) +
      " A" + rOuter + " " + rOuter + " 0 0 0 " + fmt(p2[0]) + " " + fmt(p2[1]) +
      " L" + fmt(p3[0]) + " " + fmt(p3[1]) +
      " A" + rInner + " " + rInner + " 0 0 1 " + fmt(p4[0]) + " " + fmt(p4[1]) + " Z"
    );
  }

  function line(r1, r2, angle, stroke, width) {
    var a = point(r1, angle);
    var b = point(r2, angle);
    return (
      '<line x1="' + fmt(a[0]) + '" y1="' + fmt(a[1]) + '" x2="' + fmt(b[0]) + '" y2="' + fmt(b[1]) +
      '" stroke="' + stroke + '" stroke-width="' + width + '"/>'
    );
  }

  function text(content, x, y, size, fill, extra) {
    return (
      '<text x="' + fmt(x) + '" y="' + fmt(y) + '" font-size="' + size + '" fill="' + fill +
      '" text-anchor="middle" dominant-baseline="central" ' + (extra || "") + ">" + content + "</text>"
    );
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"]/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c];
    });
  }

  // Push crowded planets apart so their glyphs do not overlap.
  function spread(items, gap) {
    var n = items.length;
    var arr = items
      .map(function (it) { return { body: it.body, angle: it.angle, shown: it.angle }; })
      .sort(function (a, b) { return a.angle - b.angle; });
    if (n < 2) return arr;
    for (var pass = 0; pass < 80; pass++) {
      var moved = false;
      for (var i = 0; i < n; i++) {
        var a = arr[i];
        var b = arr[(i + 1) % n];
        var diff = b.shown - a.shown + (i === n - 1 ? 360 : 0);
        if (diff < gap) {
          var push = (gap - diff) / 2;
          a.shown -= push;
          b.shown += push;
          moved = true;
        }
      }
      if (!moved) break;
    }
    return arr;
  }

  function buildWheel(data) {
    var asc = data.ascSignIndex;
    var out = [];
    out.push(
      '<svg class="wheel" viewBox="0 0 ' + SIZE + " " + SIZE +
      '" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Birth chart wheel" ' +
      "font-family=\"" + FONT_SYMBOLS + "\">"
    );

    // Zodiac band: twelve wedges tinted by element.
    for (var i = 0; i < 12; i++) {
      var a1 = screenAngle(i * 30, asc);
      var sign = SIGNS[i];
      out.push('<path d="' + wedge(R.sign, R.outer, a1, a1 + 30) + '" fill="' + COLORS[sign.element] + '" stroke="' + COLORS.line + '" stroke-width="1"/>');
      var g = point((R.sign + R.outer) / 2, a1 + 15);
      out.push(text(sign.glyph, g[0], g[1], 24, COLORS.ink, 'aria-hidden="true"'));
    }

    // Middle field and house ring.
    out.push('<circle cx="' + C + '" cy="' + C + '" r="' + R.sign + '" fill="' + COLORS.paper + '" stroke="' + COLORS.line + '" stroke-width="1"/>');
    out.push('<circle cx="' + C + '" cy="' + C + '" r="' + R.houseOuter + '" fill="none" stroke="' + COLORS.line + '" stroke-width="1"/>');
    out.push('<circle cx="' + C + '" cy="' + C + '" r="' + R.inner + '" fill="#FFFFFF" stroke="' + COLORS.line + '" stroke-width="1"/>');

    // House dividers (whole-sign cusps) and house numbers.
    for (var h = 0; h < 12; h++) {
      var cusp = 180 + h * 30;
      var angular = h % 3 === 0;
      out.push(line(R.inner, R.sign, cusp, angular ? COLORS.soft : COLORS.line, angular ? 1.6 : 1));
      var n = point((R.inner + R.houseOuter) / 2, cusp + 15);
      out.push(text(String(h + 1), n[0], n[1], 11, COLORS.soft, 'aria-hidden="true"'));
    }

    // Degree ticks along the inside of the zodiac band.
    for (var d = 0; d < 360; d++) {
      var ang = 180 + d;
      var len = d % 10 === 0 ? 11 : d % 5 === 0 ? 7 : 4;
      if (d % 30 === 0) continue;
      out.push(line(R.sign, R.sign - len, ang, COLORS.line, 1));
    }

    // Planets.
    var items = data.placements.map(function (p) {
      return { body: p.body, angle: screenAngle(p.longitude, asc) - 180 };
    });
    var shownByBody = {};
    spread(items, 11).forEach(function (s) { shownByBody[s.body] = s.shown + 180; });

    data.placements.forEach(function (p) {
      var trueAngle = screenAngle(p.longitude, asc);
      var shown = shownByBody[p.body];
      var isAsc = p.body === "Ascendant";
      var fill = isAsc ? COLORS.accent : COLORS.ink;

      var tickA = point(R.sign, trueAngle);
      var tickB = point(R.sign - 13, trueAngle);
      var linkEnd = point(R.glyph + 15, shown);
      var gp = point(R.glyph, shown);
      var dp = point(R.degree - (isAsc ? 14 : 0), shown);
      var label = p.degree + "\u00b0" + (p.retrograde ? " \u211E" : "");
      var title = p.body + " " + p.position + " " + p.sign + (p.retrograde ? ", retrograde" : "") + ", house " + p.house;

      out.push('<g class="planet" data-body="' + escapeHtml(p.body) + '" tabindex="0" role="button" aria-label="' + escapeHtml(title) + '">');
      out.push("<title>" + escapeHtml(title) + "</title>");
      out.push('<line x1="' + fmt(tickA[0]) + '" y1="' + fmt(tickA[1]) + '" x2="' + fmt(tickB[0]) + '" y2="' + fmt(tickB[1]) + '" stroke="' + fill + '" stroke-width="2"/>');
      out.push('<line x1="' + fmt(tickB[0]) + '" y1="' + fmt(tickB[1]) + '" x2="' + fmt(linkEnd[0]) + '" y2="' + fmt(linkEnd[1]) + '" stroke="' + COLORS.line + '" stroke-width="1"/>');
      out.push('<circle class="planet-halo" cx="' + fmt(gp[0]) + '" cy="' + fmt(gp[1]) + '" r="17" fill="' + COLORS.paper + '" stroke="none"/>');
      out.push(text(escapeHtml(p.glyph), gp[0], gp[1], isAsc ? 15 : 24, fill, isAsc ? 'font-weight="700"' : ""));
      out.push(text(escapeHtml(label), dp[0], dp[1], 11, COLORS.soft));
      out.push("</g>");
    });

    out.push("</svg>");
    return out.join("");
  }

  function mountWheel(element, data) {
    element.innerHTML = buildWheel(data);
    return element.firstChild;
  }

  var api = { buildWheel: buildWheel, mountWheel: mountWheel, screenAngle: screenAngle };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.Astra = api;
})(typeof window !== "undefined" ? window : this);
