CREATE TABLE IF NOT EXISTS charts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL CHECK (length(trim(name)) > 0),
    birth_date  TEXT,
    birth_time  TEXT,
    birth_place TEXT,
    is_sample   INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0, 1)),
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS placements (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    chart_id   INTEGER NOT NULL REFERENCES charts (id) ON DELETE CASCADE,
    body       TEXT NOT NULL,
    sign       TEXT NOT NULL,
    degree     INTEGER NOT NULL CHECK (degree BETWEEN 0 AND 29),
    minute     INTEGER NOT NULL CHECK (minute BETWEEN 0 AND 59),
    retrograde INTEGER NOT NULL DEFAULT 0 CHECK (retrograde IN (0, 1)),
    UNIQUE (chart_id, body)
);

CREATE INDEX IF NOT EXISTS idx_placements_chart ON placements (chart_id);
