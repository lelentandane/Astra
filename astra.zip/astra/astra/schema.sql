CREATE TABLE IF NOT EXISTS charts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL CHECK (length(trim(name)) > 0),
    birth_date  TEXT,
    birth_time  TEXT,
    birth_place TEXT,
    is_sample   INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0, 1)),
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS placements (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    chart_id   INTEGER NOT NULL REFERENCES charts (id) ON DELETE CASCADE,
    body       TEXT NOT NULL,
    sign       TEXT NOT NULL,
    degree     INTEGER NOT NULL CHECK (degree BETWEEN 0 AND 29),
    minute     INTEGER NOT NULL CHECK (minute BETWEEN 0 AND 59),
    retrograde INTEGER NOT NULL DEFAULT 0 CHECK (retrograde IN (0, 1)),
    UNIQUE (chart_id, body)
);

CREATE INDEX IF NOT EXISTS idx_placements_chart ON placements (chart_id);

-- Interpretation pieces used to build readings. Seeded from content.py on startup.
CREATE TABLE IF NOT EXISTS interpretations (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    kind    TEXT NOT NULL CHECK (kind IN ('body', 'sign', 'house', 'aspect')),
    key     TEXT NOT NULL,
    keyword TEXT NOT NULL,
    text    TEXT NOT NULL,
    UNIQUE (kind, key)
);

CREATE TABLE IF NOT EXISTS interpretation_topics (
    interpretation_id INTEGER NOT NULL REFERENCES interpretations (id) ON DELETE CASCADE,
    topic             TEXT NOT NULL,
    PRIMARY KEY (interpretation_id, topic)
);

-- Journal notes. body is NULL for a note about the whole chart.
CREATE TABLE IF NOT EXISTS notes (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    chart_id   INTEGER NOT NULL REFERENCES charts (id) ON DELETE CASCADE,
    body       TEXT,
    content    TEXT NOT NULL CHECK (length(trim(content)) > 0),
    entry_date TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_notes_chart ON notes (chart_id, entry_date DESC);
