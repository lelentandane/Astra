/* Home page empty state: shows a sample wheel. */
(function () {
  "use strict";
  var dataEl = document.getElementById("demo-data");
  var mount = document.getElementById("demo-wheel");
  if (dataEl && mount) window.Astra.mountWheel(mount, JSON.parse(dataEl.textContent));
})();
