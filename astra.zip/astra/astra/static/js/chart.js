/*
 * Chart page behaviour:
 * - draws the wheel
 * - tabs (Placements, Aspects, Reading)
 * - selecting a body shows its reading and notes
 * - topic chips dim everything that is not relevant
 * - hovering links the wheel, the table and the aspect lines
 */
(function () {
  "use strict";

  var chartEl = document.getElementById("chart-data");
  var readingEl = document.getElementById("reading-data");
  var mount = document.getElementById("wheel");
  if (!chartEl || !readingEl || !mount) return;

  var data = JSON.parse(readingEl.textContent);
  var readings = data.readings;
  var notes = data.notes;
  var svg = window.Astra.mountWheel(mount, JSON.parse(chartEl.textContent));
  var reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  // ---------------------------------------------------------------- helpers
  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function planetEl(body) { return svg.querySelector('.planet[data-body="' + body + '"]'); }
  function rowEl(body) { return document.querySelector('[data-row="' + body + '"]'); }

  // ---------------------------------------------------------------- tabs
  var tabs = Array.prototype.slice.call(document.querySelectorAll('[role="tab"]'));

  function showTab(tab, focus) {
    tabs.forEach(function (t) {
      var on = t === tab;
      t.setAttribute("aria-selected", on ? "true" : "false");
      t.tabIndex = on ? 0 : -1;
      document.getElementById(t.getAttribute("aria-controls")).hidden = !on;
    });
    if (focus) tab.focus();
  }

  tabs.forEach(function (tab, index) {
    tab.addEventListener("click", function () { showTab(tab, false); });
    tab.addEventListener("keydown", function (event) {
      var next = null;
      if (event.key === "ArrowRight") next = tabs[(index + 1) % tabs.length];
      if (event.key === "ArrowLeft") next = tabs[(index - 1 + tabs.length) % tabs.length];
      if (event.key === "Home") next = tabs[0];
      if (event.key === "End") next = tabs[tabs.length - 1];
      if (next) { event.preventDefault(); showTab(next, true); }
    });
  });

  // ---------------------------------------------------------------- hover links
  function setActive(body, on) {
    var planet = planetEl(body);
    var row = rowEl(body);
    if (planet) planet.classList.toggle("is-active", on);
    if (row) row.classList.toggle("is-active", on);
  }

  svg.querySelectorAll(".planet").forEach(function (node) {
    var body = node.getAttribute("data-body");
    node.addEventListener("mouseenter", function () { setActive(body, true); });
    node.addEventListener("mouseleave", function () { setActive(body, false); });
    node.addEventListener("focus", function () { setActive(body, true); });
    node.addEventListener("blur", function () { setActive(body, false); });
    node.addEventListener("click", function () { selectBody(body, true); });
    node.addEventListener("keydown", function (event) {
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        selectBody(body, true);
      }
    });
  });

  document.querySelectorAll("[data-row]").forEach(function (row) {
    var body = row.getAttribute("data-row");
    row.addEventListener("mouseenter", function () { setActive(body, true); });
    row.addEventListener("mouseleave", function () { setActive(body, false); });
  });

  document.querySelectorAll("[data-select]").forEach(function (button) {
    button.addEventListener("click", function () { selectBody(button.getAttribute("data-select"), true); });
  });

  function setAspectHighlight(a, b, on) {
    svg.querySelectorAll(".aspect-line").forEach(function (line) {
      var match = line.getAttribute("data-a") === a && line.getAttribute("data-b") === b;
      line.classList.toggle("is-hot", on && match);
      line.classList.toggle("is-faded", on && !match);
    });
    [a, b].forEach(function (body) { setActive(body, on); });
  }

  document.querySelectorAll("[data-aspect-a]").forEach(function (row) {
    var a = row.getAttribute("data-aspect-a");
    var b = row.getAttribute("data-aspect-b");
    row.addEventListener("mouseenter", function () { setAspectHighlight(a, b, true); });
    row.addEventListener("mouseleave", function () { setAspectHighlight(a, b, false); });
  });

  // ---------------------------------------------------------------- reading panel
  var selected = null;

  function selectBody(body, scroll) {
    var reading = readings[body];
    if (!reading) return;
    selected = body;

    svg.querySelectorAll(".planet").forEach(function (p) {
      p.classList.toggle("is-selected", p.getAttribute("data-body") === body);
    });
    document.querySelectorAll("[data-row]").forEach(function (r) {
      r.classList.toggle("is-selected", r.getAttribute("data-row") === body);
    });

    document.getElementById("reading-title").textContent = reading.title;

    var parts = document.getElementById("reading-parts");
    parts.textContent = "";
    reading.parts.forEach(function (part) {
      var wrap = el("div", "reading-part");
      var dt = el("dt");
      dt.appendChild(el("span", "part-label", part.label));
      dt.appendChild(el("span", "part-keyword", part.keyword));
      wrap.appendChild(dt);
      wrap.appendChild(el("dd", null, part.text));
      parts.appendChild(wrap);
    });

    var aspectList = document.getElementById("reading-aspects");
    aspectList.textContent = "";
    reading.aspects.forEach(function (asp) {
      var li = el("li", "reading-aspect");
      var head = el("p", "aspect-head");
      head.appendChild(el("span", "nature nature-" + asp.nature, asp.label));
      head.appendChild(el("span", "aspect-orb", "orb " + asp.orbText));
      li.appendChild(head);
      li.appendChild(el("p", "aspect-text", asp.text));
      aspectList.appendChild(li);
    });
    document.getElementById("reading-aspects-heading").hidden = reading.aspects.length === 0;

    var noteList = document.getElementById("reading-notes");
    noteList.textContent = "";
    var mine = notes[body] || [];
    if (!mine.length) {
      noteList.appendChild(el("li", "empty-note", "No notes on this placement yet."));
    }
    mine.forEach(function (note) {
      var li = el("li", "note");
      li.appendChild(el("p", "note-date", note.entryDate));
      li.appendChild(el("p", "note-text", note.content));
      noteList.appendChild(li);
    });

    document.getElementById("note-body").value = body;
    document.getElementById("reading-empty").hidden = true;
    document.getElementById("reading-content").hidden = false;
    showTab(document.getElementById("tab-reading"), false);

    if (history.replaceState) {
      history.replaceState(null, "", "?body=" + encodeURIComponent(body) + "#reading");
    }
    if (scroll) {
      var title = document.getElementById("reading-title");
      title.scrollIntoView({ block: "nearest", behavior: reduceMotion ? "auto" : "smooth" });
    }
  }

  // ---------------------------------------------------------------- topic chips
  var chips = Array.prototype.slice.call(document.querySelectorAll(".chip"));

  function applyTopic(topic) {
    chips.forEach(function (chip) {
      var on = chip.getAttribute("data-topic") === topic;
      chip.classList.toggle("is-on", on);
      chip.setAttribute("aria-pressed", on ? "true" : "false");
    });
    Object.keys(readings).forEach(function (body) {
      var relevant = !topic || readings[body].topics.indexOf(topic) !== -1;
      var planet = planetEl(body);
      var row = rowEl(body);
      if (planet) planet.classList.toggle("is-dim", !relevant);
      if (row) row.classList.toggle("is-dim", !relevant);
    });
  }

  chips.forEach(function (chip) {
    chip.addEventListener("click", function () { applyTopic(chip.getAttribute("data-topic")); });
  });

  // ---------------------------------------------------------------- start state
  document.getElementById("note-date").value = new Date().toISOString().slice(0, 10);

  var params = new URLSearchParams(window.location.search);
  var wanted = params.get("body");
  if (wanted && readings[wanted]) selectBody(wanted, window.location.hash === "#reading");
})();
